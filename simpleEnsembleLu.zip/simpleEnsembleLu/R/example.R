#' Example Data
#'
#' Example for the simpleEnsembleLu package.
#'
#' @format A list with two objects:
#' \describe{
#'   \item{X}{Data frame for predictors.}
#'   \item{y}{Target variable.}
#' }
#'
#' @examples
#' data(example)
#' str(example)
"example"
