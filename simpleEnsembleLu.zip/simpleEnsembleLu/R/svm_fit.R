library(e1071)

#' Support Vector Machine Fit
#'
#' This function fits a support vector machine model.
#'
#' SVM can be used for continuous response or binary response.
#'
#' For continuous response, the function fits SVM regression.
#' For binary response, the function fits SVM classification.
#'
#' @param X A matrix or data frame of predictors.
#' @param y A continuous or binary response vector.
#' @param kernel The kernel used in SVM. The default is "radial".
#' @param cost The cost parameter. The default is 1.
#' @param scale A Boolean indicating whether to scale the predictors. The default is TRUE.
#'
#' @return A fitted SVM model.
#'
#' @examples
#' data(example_data)
#' svm_fit(example_data$X, example_data$y)
#'
#' @export
#' 
svm_fit <- function(X, y, kernel = "radial", cost = 1, scale = TRUE){
  
  dat_info <- input_data(X, y)
  
  X <- dat_info$X
  y <- dat_info$y
  
  if (cost <= 0){
    stop("cost must be positive.")
  }
  
  if (!is.logical(scale) | length(scale) != 1){
    stop("scale must be TRUE or FALSE.")
  }
  
  if (dat_info$y.type == "binary"){
    y <- as.factor(y)
  }
  
  dat <- data.frame(y = y, X)
  
  fit <- svm(y ~ ., data = dat, kernel = kernel, cost = cost, scale = scale)
  
  return(fit)
}