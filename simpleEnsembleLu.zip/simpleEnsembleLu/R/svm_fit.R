library(e1071)

#' Support Vector Machine Fit
#'
#' This function fits a support vector machine model.
#'
#' SVM can be used for continuous response or binary response.
#'
#' For continuous response, the function fits SVM regression.
#' For binary response, the function fits SVM classification.
#'
#' The default scale = TRUE is recommended because SVM is sensitive to predictor scale.
#' The predictors are scaled internally to zero mean and unit variance.
#'
#' @param X A matrix or data frame of predictors.
#' @param y A continuous or binary response vector.
#' @param type The SVM type. The default is "auto", so svm() chooses the type
#' automatically based on y. Other choices are "C-classification",
#' "nu-classification", "eps-regression", and "nu-regression".
#' @param kernel The kernel used in training and prediction. The default is
#' "radial". Other choices are "linear", "polynomial", and "sigmoid".
#' @param degree The degree parameter needed for polynomial kernel. The default is 3.
#' @param gamma The gamma parameter needed for all kernels except linear.
#' The default is 1 divided by the number of predictors.
#' @param coef0 The coef0 parameter needed for polynomial and sigmoid kernels.
#' The default is 0.
#' @param cost The cost of constraint violation. The default is 1.
#' @param class.weights A named vector of weights for different classes, used for
#' asymmetric class sizes. Not all factor levels have to be supplied. The default
#' weight is 1.
#' @param epsilon The epsilon parameter in the insensitive-loss function for
#' regression. The default is 0.1.
#' @param probability A Boolean indicating whether the model allows probability
#' prediction. The default is FALSE.
#' @param scale A Boolean indicating whether to scale the predictors. The default
#' is TRUE.
#'
#' @return A fitted SVM model.
#'
#' @examples
#' data(example_data)
#' svm_fit(example_data$X, example_data$y)
#'
#' @export
#' 
svm_fit <- function(X, y,
                    type = c("auto", "C-classification", "nu-classification",
                             "eps-regression", "nu-regression"),
                    kernel = c("radial", "linear", "polynomial", "sigmoid"),
                    degree = 3, gamma = NULL, coef0 = 0, cost = 1, class.weights = NULL, 
                    epsilon = 0.1, probability = FALSE, scale = TRUE){
  
  dat_info <- input_data(X, y)
  
  X <- dat_info$X
  y <- dat_info$y
  
  type <- match.arg(type)
  kernel <- match.arg(kernel)
  
  if (degree < 1 | floor(degree) != degree){
    stop("degree must be a positive integer.")
  }
  
  if (!is.null(gamma) & gamma <= 0){
    stop("gamma must be positive.")
  }
  
  if (cost <= 0){
    stop("cost must be positive.")
  }
  
  if (epsilon <= 0){
    stop("epsilon must be positive.")
  }
  
  if (!is.logical(probability) | length(probability) != 1){
    stop("probability must be TRUE or FALSE.")
  }
  
  if (!is.logical(scale) | length(scale) != 1){
    stop("scale must be TRUE or FALSE.")
  }
  
  if (dat_info$y.type == "binary"){
    y <- as.factor(y)
  }
  
  if (is.null(gamma)){
    gamma <- 1 / ncol(X)
  }
  
  dat <- data.frame(y = y, X)
  
  if (type == "auto"){
    fit <- svm(y ~ ., data = dat, kernel = kernel, degree = degree,
               gamma = gamma, coef0 = coef0, cost = cost,
               class.weights = class.weights, epsilon = epsilon,
               probability = probability, scale = scale)
  } else {
    fit <- svm(y ~ ., data = dat, type = type, kernel = kernel,
               degree = degree, gamma = gamma, coef0 = coef0, cost = cost,
               class.weights = class.weights, epsilon = epsilon,
               probability = probability, scale = scale)
  }
  
  return(fit)
}